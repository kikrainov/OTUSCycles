/*Сгенерировать массив случайных чисел

Описание/Пошаговая инструкция выполнения домашнего задания:
Сгенерировать массив случайных чисел (например 200 чисел). Найти индекс первого повторяющегося числа в массиве. Если все числа разные - то -1.
Пример : [3, 4, 5, 6, 8, 78, 67, 4, 88] - 4, индекс 1

*/

// 0. Начнём с массива для Int-ов
var intArray: [Int] = []

for _ in 0..<200 {
    intArray.append(Int.random(in: 0...199))
}

print(intArray)

func findFirstDuplicate(array: [Int]) -> Int {
    // коллекция для ключ-значений
    var localDict: [Int: Int] = [:]
    
    // храним минимальный индекс
    var minIndex = Int.max
    // заводим предыдущий индекс
    
    for i in 0..<array.count {
        if let previousIndex = localDict[intArray[i]] {
            if minIndex > previousIndex {
                minIndex = previousIndex
            }
        }
        localDict[intArray[i]] = i
    }
    return minIndex == Int.max ? -1 : minIndex
}

let example = findFirstDuplicate(array: intArray)
print(example)

